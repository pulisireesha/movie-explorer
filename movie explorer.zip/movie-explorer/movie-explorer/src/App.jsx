import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import Home from "./pages/Home.jsx";
import MovieDetails from "./pages/MovieDetails.jsx";
import NotFound from "./pages/NotFound.jsx";

// App defines the page layout and the routes
function App() {
  return (
    <div className="app">
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movie/:id" element={<MovieDetails />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <footer className="footer">
        <p>
          Movie data from{" "}
          <a href="https://www.omdbapi.com/" target="_blank" rel="noopener noreferrer">
            OMDb API
          </a>
          . Built with React and Vite.
        </p>
      </footer>
    </div>
  );
}

export default App;
