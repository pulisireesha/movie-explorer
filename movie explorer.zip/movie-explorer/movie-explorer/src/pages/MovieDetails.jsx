import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import Poster from "../components/Poster.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import { getMovieById, getErrorMessage } from "../api/omdb.js";

// Show "N/A" values from the API as "Not available"
const clean = (value) => (!value || value === "N/A" ? "Not available" : value);

function MovieDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [movie, setMovie] = useState(null);
  const [status, setStatus] = useState("loading");
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setStatus("loading");
      try {
        const data = await getMovieById(id);
        if (cancelled) return;
        setMovie(data);
        setStatus("success");
      } catch (err) {
        if (cancelled) return;
        setError(getErrorMessage(err));
        setStatus("error");
      }
    }

    load();
    window.scrollTo(0, 0);
    return () => {
      cancelled = true;
    };
  }, [id]);

  // Go back to the previous page, or home if the page was opened directly
  function goBack() {
    if (window.history.state && window.history.state.idx > 0) {
      navigate(-1);
    } else {
      navigate("/");
    }
  }

  return (
    <section>
      <button type="button" className="back-btn" onClick={goBack}>
        ← Back to results
      </button>

      {status === "loading" && <Loader text="Loading movie details..." />}

      {status === "error" && (
        <>
          <ErrorMessage message={error} />
          <p className="center">
            <Link to="/">Go to the home page</Link>
          </p>
        </>
      )}

      {status === "success" && movie && (
        <article className="details">
          <Poster src={movie.Poster} title={movie.Title} className="details-poster" />

          <div className="details-info">
            <h1>{movie.Title}</h1>
            <p className="details-sub">
              {clean(movie.Year)} · {clean(movie.Rated)} · {clean(movie.Runtime)}
            </p>

            <div className="genre-list">
              {movie.Genre &&
                movie.Genre !== "N/A" &&
                movie.Genre.split(",").map((g) => (
                  <span key={g} className="genre-tag">
                    {g.trim()}
                  </span>
                ))}
            </div>

            <p className="rating big">
              ⭐ {movie.imdbRating && movie.imdbRating !== "N/A" ? `${movie.imdbRating} / 10` : "No rating"}
              {movie.imdbVotes && movie.imdbVotes !== "N/A" && <small> ({movie.imdbVotes} votes)</small>}
            </p>

            <h2>Plot</h2>
            <p>{clean(movie.Plot)}</p>

            <dl className="facts">
              <dt>Director</dt>
              <dd>{clean(movie.Director)}</dd>
              <dt>Writer</dt>
              <dd>{clean(movie.Writer)}</dd>
              <dt>Cast</dt>
              <dd>{clean(movie.Actors)}</dd>
              <dt>Released</dt>
              <dd>{clean(movie.Released)}</dd>
              <dt>Language</dt>
              <dd>{clean(movie.Language)}</dd>
              <dt>Country</dt>
              <dd>{clean(movie.Country)}</dd>
              <dt>Awards</dt>
              <dd>{clean(movie.Awards)}</dd>
              <dt>Box office</dt>
              <dd>{clean(movie.BoxOffice)}</dd>
            </dl>
          </div>
        </article>
      )}
    </section>
  );
}

export default MovieDetails;
