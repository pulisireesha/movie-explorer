import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import SearchBar from "../components/SearchBar.jsx";
import MovieCard from "../components/MovieCard.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import { searchMovies, getErrorMessage } from "../api/omdb.js";

const SUGGESTIONS = ["Avatar", "Batman", "Inception", "The Matrix"];

function Home() {
  // The search is stored in the URL (?q=Avatar) so Back from a details page restores it
  const [searchParams, setSearchParams] = useSearchParams();
  const query = searchParams.get("q") || "";
  const type = searchParams.get("type") || "";

  const [movies, setMovies] = useState([]);
  const [totalResults, setTotalResults] = useState(0);
  const [page, setPage] = useState(1);
  const [status, setStatus] = useState("idle"); // idle | loading | success | error
  const [error, setError] = useState("");
  const [loadingMore, setLoadingMore] = useState(false);

  // Load the first page whenever the search changes
  useEffect(() => {
    if (!query) {
      setStatus("idle");
      setMovies([]);
      return;
    }

    let cancelled = false; // ignore old responses if the user searches again

    async function load() {
      setStatus("loading");
      setError("");
      try {
        const data = await searchMovies(query, { page: 1, type });
        if (cancelled) return;
        setMovies(data.movies);
        setTotalResults(data.totalResults);
        setPage(1);
        setStatus("success");
      } catch (err) {
        if (cancelled) return;
        setMovies([]);
        setError(getErrorMessage(err));
        setStatus("error");
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [query, type]);

  function handleSearch(text, selectedType) {
    const params = { q: text };
    if (selectedType) params.type = selectedType;
    setSearchParams(params);
  }

  async function handleLoadMore() {
    setLoadingMore(true);
    try {
      const nextPage = page + 1;
      const data = await searchMovies(query, { page: nextPage, type });
      // Avoid duplicate cards if the API repeats an item
      setMovies((current) => {
        const seen = new Set(current.map((m) => m.imdbID));
        return [...current, ...data.movies.filter((m) => !seen.has(m.imdbID))];
      });
      setPage(nextPage);
    } catch (err) {
      setError(getErrorMessage(err));
      setStatus("error");
    } finally {
      setLoadingMore(false);
    }
  }

  return (
    <section>
      <div className="hero">
        <h1>Find your next movie</h1>
        <p>Search by title to see ratings, posters and details.</p>
      </div>

      <SearchBar initialValue={query} initialType={type} onSearch={handleSearch} />

      {status === "idle" && (
        <div className="suggestions">
          <p>Try searching for:</p>
          <div className="chips">
            {SUGGESTIONS.map((name) => (
              <button key={name} type="button" className="chip" onClick={() => handleSearch(name, "")}>
                {name}
              </button>
            ))}
          </div>
        </div>
      )}

      {status === "loading" && <Loader text="Searching movies..." />}
      {status === "error" && <ErrorMessage message={error} />}

      {status === "success" && (
        <>
          <p className="result-count">
            Showing {movies.length} of {totalResults} results for "{query}"
          </p>
          <div className="movie-grid">
            {movies.map((movie) => (
              <MovieCard key={movie.imdbID} movie={movie} />
            ))}
          </div>

          {movies.length < totalResults && (
            <div className="load-more">
              <button type="button" onClick={handleLoadMore} disabled={loadingMore}>
                {loadingMore ? "Loading..." : "Load more"}
              </button>
            </div>
          )}
        </>
      )}
    </section>
  );
}

export default Home;
