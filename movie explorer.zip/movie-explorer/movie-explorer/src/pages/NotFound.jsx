import { Link } from "react-router-dom";

function NotFound() {
  return (
    <section className="center not-found">
      <h1>404</h1>
      <p>This page does not exist.</p>
      <Link to="/" className="link-btn">
        Back to home
      </Link>
    </section>
  );
}

export default NotFound;
