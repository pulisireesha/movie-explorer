import { Link } from "react-router-dom";
import Poster from "./Poster.jsx";

// One movie in the results grid. Clicking it opens the details page.
function MovieCard({ movie }) {
  const hasRating = movie.imdbRating && movie.imdbRating !== "N/A";
  const genre = movie.Genre && movie.Genre !== "N/A" ? movie.Genre.split(",")[0] : null;

  return (
    <Link to={`/movie/${movie.imdbID}`} className="movie-card">
      <Poster src={movie.Poster} title={movie.Title} />
      <div className="card-body">
        <h3 className="card-title">{movie.Title}</h3>
        <p className="card-meta">
          {movie.Year} · <span className="capitalize">{movie.Type}</span>
          {genre && <> · {genre}</>}
        </p>
        <p className="rating">⭐ {hasRating ? `${movie.imdbRating} / 10` : "No rating"}</p>
      </div>
    </Link>
  );
}

export default MovieCard;
