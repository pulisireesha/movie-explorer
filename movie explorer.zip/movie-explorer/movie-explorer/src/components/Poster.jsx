import { useState } from "react";

// Shows the poster, or a placeholder when there is none or it fails to load.
function Poster({ src, title, className = "poster" }) {
  const [failed, setFailed] = useState(false);
  const missing = !src || src === "N/A" || failed;

  if (missing) {
    return (
      <div className={`${className} poster-placeholder`} role="img" aria-label={`No poster for ${title}`}>
        <span aria-hidden="true">🎞️</span>
        <small>No poster</small>
      </div>
    );
  }

  return (
    <img
      className={className}
      src={src}
      alt={`${title} poster`}
      loading="lazy"
      onError={() => setFailed(true)}
    />
  );
}

export default Poster;
