import { Link } from "react-router-dom";

function Navbar() {
  return (
    <header className="navbar">
      <Link to="/" className="brand">
        <span aria-hidden="true">🎬</span> Movie Explorer
      </Link>
    </header>
  );
}

export default Navbar;
