import { useState, useEffect } from "react";

// Controlled search form. Works with the Search button and the Enter key.
function SearchBar({ initialValue, initialType, onSearch }) {
  const [text, setText] = useState(initialValue);
  const [type, setType] = useState(initialType);
  const [validation, setValidation] = useState("");

  // Keep the input in sync when the URL changes (for example the back button)
  useEffect(() => {
    setText(initialValue);
    setType(initialType);
  }, [initialValue, initialType]);

  function handleSubmit(event) {
    event.preventDefault();
    const trimmed = text.trim();

    if (trimmed === "") {
      setValidation("Please enter a movie title.");
      return;
    }
    setValidation("");
    onSearch(trimmed, type);
  }

  return (
    <form className="search-form" onSubmit={handleSubmit} noValidate>
      <div className="search-row">
        <label htmlFor="movie-search" className="visually-hidden">
          Movie title
        </label>
        <input
          id="movie-search"
          type="text"
          placeholder="Search for a movie, e.g. Avatar"
          value={text}
          onChange={(e) => setText(e.target.value)}
          autoComplete="off"
        />
        <label htmlFor="movie-type" className="visually-hidden">
          Type
        </label>
        <select id="movie-type" value={type} onChange={(e) => setType(e.target.value)}>
          <option value="">All types</option>
          <option value="movie">Movies</option>
          <option value="series">Series</option>
        </select>
        <button type="submit">Search</button>
      </div>
      {validation && (
        <p className="validation" role="alert">
          {validation}
        </p>
      )}
    </form>
  );
}

export default SearchBar;
