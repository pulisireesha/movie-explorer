function Loader({ text = "Loading..." }) {
  return (
    <div className="loader" role="status">
      <div className="spinner" aria-hidden="true"></div>
      <p>{text}</p>
    </div>
  );
}

export default Loader;
