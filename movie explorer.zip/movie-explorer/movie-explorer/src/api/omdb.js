// All communication with the OMDb API lives in this file.
const BASE_URL = "https://www.omdbapi.com/";
const API_KEY = import.meta.env.VITE_OMDB_API_KEY;

/** Send a request to OMDb and return the parsed JSON, or throw a readable error code. */
async function request(params) {
  if (!API_KEY || API_KEY === "your_api_key_here") {
    throw new Error("MISSING_KEY");
  }

  const query = new URLSearchParams({ apikey: API_KEY, ...params });
  const response = await fetch(`${BASE_URL}?${query.toString()}`);

  if (response.status === 401) throw new Error("INVALID_KEY");
  if (!response.ok) throw new Error("NETWORK");

  const data = await response.json();

  // OMDb answers with HTTP 200 and Response: "False" when something is wrong
  if (data.Response === "False") {
    if (data.Error === "Invalid API key!") throw new Error("INVALID_KEY");
    if (data.Error === "Too many results.") throw new Error("TOO_MANY");
    if (/limit/i.test(data.Error)) throw new Error("LIMIT");
    throw new Error("NOT_FOUND");
  }
  return data;
}

/**
 * Search movies by title. The search endpoint has no rating, so we also load
 * each result's details to get the IMDb rating and genre for the cards.
 */
export async function searchMovies(title, { page = 1, type = "" } = {}) {
  const params = { s: title, page };
  if (type) params.type = type;

  const data = await request(params);
  const results = Array.isArray(data.Search) ? data.Search : [];

  const detailed = await Promise.allSettled(results.map((movie) => request({ i: movie.imdbID })));

  const movies = results.map((movie, index) => {
    const detail = detailed[index].status === "fulfilled" ? detailed[index].value : {};
    return {
      ...movie,
      imdbRating: detail.imdbRating,
      Genre: detail.Genre,
    };
  });

  return { movies, totalResults: Number(data.totalResults) || movies.length };
}

/** Get the full details of one movie by its IMDb ID. */
export async function getMovieById(id) {
  return request({ i: id, plot: "full" });
}

/** Turn an error code into a friendly message for the user. */
export function getErrorMessage(error) {
  switch (error.message) {
    case "MISSING_KEY":
      return "API key missing. Create a .env file with VITE_OMDB_API_KEY (see README).";
    case "INVALID_KEY":
      return "The API key is invalid. Check the key in your .env file and restart the dev server.";
    case "NOT_FOUND":
      return "No movies found. Try a different title.";
    case "TOO_MANY":
      return "Too many results. Try a longer or more specific title.";
    case "LIMIT":
      return "The daily API request limit was reached. Try again tomorrow.";
    default:
      return "Could not reach the movie service. Check your internet connection and try again.";
  }
}
